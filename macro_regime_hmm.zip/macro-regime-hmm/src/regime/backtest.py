"""
backtest.py  ·  macro-regime-hmm
==================================
Regime-conditional factor portfolio backtest.

Strategy
--------
At each month t, observe the predicted regime and allocate to a
factor-tilted equity portfolio:

    Expansion  → overweight Momentum + Market (growth regime)
    Slowdown   → overweight Quality (RMW) + Value (HML) + underweight MOM
    Crisis     → overweight Low-Beta / defensive, underweight Market

The allocation uses the Fama-French factor returns as a proxy.
In practice you'd implement this through long/short equity positions
that load on each factor. Here we use direct factor returns for clarity.

Benchmark: static equal-weight across all factors.

Performance metrics
-------------------
CAGR, annualised volatility, Sharpe ratio, max drawdown, and Calmar ratio.
Plus turnover and regime-conditional Sharpe decomposition.

Why this matters for PanAgora
-------------------------------
PanAgora manages multi-asset strategies explicitly designed around
macro regimes. Edward Qian's "risk parity" framework allocates by risk
contribution, but their multi-asset team (Macro Quantitative Strategies)
explicitly conditions on macro regimes for tactical tilts. This backtest
demonstrates exactly that workflow.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

# Factor allocation weights by regime: {factor: weight}
# Weights are relative — normalised to sum to 1 in run_backtest
REGIME_WEIGHTS: Dict[int, Dict[str, float]] = {
    0: {  # Expansion
        "Mkt-RF": 1.0,
        "MOM":    1.5,   # momentum works in expansion
        "RMW":    0.5,
        "HML":    0.5,
        "SMB":    0.5,
        "CMA":    0.3,
    },
    1: {  # Slowdown
        "Mkt-RF": 0.7,
        "MOM":    0.2,   # momentum starts decaying
        "RMW":    1.5,   # quality/profitability
        "HML":    1.2,   # value
        "SMB":    0.3,
        "CMA":    1.0,
    },
    2: {  # Crisis
        "Mkt-RF": 0.3,   # reduce market beta
        "MOM":    0.1,   # momentum crashes in crisis (Barroso & Santa-Clara 2015)
        "RMW":    2.0,   # quality is most defensive
        "HML":    0.5,
        "SMB":    0.3,
        "CMA":    0.8,
    },
}


def run_backtest(
    regime_series:  pd.Series,
    factor_returns: pd.DataFrame,
    tc_bps:         float = 5.0,   # one-way transaction cost (lower for factor strategies)
) -> Dict:
    """
    Simulate the regime-conditional factor portfolio.

    Parameters
    ----------
    regime_series  : monthly predicted regime (0=Expansion, 1=Slowdown, 2=Crisis)
    factor_returns : monthly FF6 factor returns (cols = Mkt-RF, SMB, etc.)
    tc_bps         : one-way transaction cost in basis points

    Returns
    -------
    dict with 'returns' (pd.Series), 'benchmark' (pd.Series), 'metrics' (dict),
              'regime_series' (pd.Series)
    """
    tc          = tc_bps / 10_000
    factor_cols = [c for c in ["Mkt-RF", "SMB", "HML", "RMW", "CMA", "MOM"]
                   if c in factor_returns.columns]

    common = regime_series.dropna().index.intersection(factor_returns.index)
    regimes = regime_series.reindex(common).fillna(0).astype(int)
    factors = factor_returns.reindex(common)[factor_cols]

    port_rets  = []
    bench_rets = []
    prev_w     = None

    for t, date in enumerate(common):
        k = int(regimes.iloc[t])
        regime_w = REGIME_WEIGHTS.get(k, REGIME_WEIGHTS[0])

        # Build normalised weight vector over available factors
        raw_w = np.array([regime_w.get(f, 0.5) for f in factor_cols])
        raw_w = np.maximum(raw_w, 0)
        total = raw_w.sum()
        w     = raw_w / total if total > 0 else np.ones(len(factor_cols)) / len(factor_cols)

        # Transaction cost on weight change
        if prev_w is not None:
            turnover = float(np.abs(w - prev_w).sum() / 2)
            tc_drag  = turnover * tc
        else:
            tc_drag = 0.0

        # Portfolio return
        f_ret    = factors.iloc[t].values
        port_ret = float(w @ f_ret) - tc_drag
        bench_ret = float(np.ones(len(factor_cols)) / len(factor_cols) @ f_ret)

        port_rets.append(port_ret)
        bench_rets.append(bench_ret)
        prev_w = w

    port_s  = pd.Series(port_rets,  index=common, name="regime_strategy")
    bench_s = pd.Series(bench_rets, index=common, name="equal_weight")

    metrics = _compute_metrics(port_s, bench_s)

    return {
        "returns":       port_s,
        "benchmark":     bench_s,
        "metrics":       metrics,
        "regime_series": regimes,
    }


def _compute_metrics(port: pd.Series, bench: pd.Series) -> Dict:
    """Full performance metrics for both portfolio and benchmark."""
    ann = 12

    def _stats(r):
        n    = len(r)
        cagr = (1 + r).prod() ** (ann / n) - 1
        vol  = r.std(ddof=1) * np.sqrt(ann)
        sr   = cagr / vol if vol > 0 else np.nan
        nav  = (1 + r).cumprod()
        peak = nav.expanding().max()
        mdd  = float((nav / peak - 1).min())
        return {"CAGR": cagr, "Vol": vol, "Sharpe": sr, "MaxDD": mdd,
                "Calmar": cagr / abs(mdd) if mdd < 0 else np.nan,
                "HitRate": (r > 0).mean()}

    p = _stats(port)
    b = _stats(bench)

    # Active return and IR
    active = port - bench
    active_ann = active.mean() * ann
    te_ann     = active.std(ddof=1) * np.sqrt(ann)
    ir         = active_ann / te_ann if te_ann > 0 else np.nan

    return {
        "Strategy": {k: round(v, 4) for k, v in p.items()},
        "Benchmark": {k: round(v, 4) for k, v in b.items()},
        "Active": {
            "Active Return": round(active_ann, 4),
            "Tracking Error": round(te_ann, 4),
            "Info Ratio": round(ir, 3) if not np.isnan(ir) else "N/A",
        },
    }


def regime_eval(
    predicted:  pd.Series,
    nber_rec:   pd.Series,
) -> Dict:
    """
    Evaluate regime predictions against NBER recession dates.
    Maps predicted crisis state (2) → recession, others → expansion.
    """
    common   = predicted.dropna().index.intersection(nber_rec.dropna().index)
    pred_rec = (predicted.reindex(common) == 2).astype(int)
    true_rec = nber_rec.reindex(common).clip(0, 1).astype(int)

    n   = len(common)
    tp  = int(((pred_rec == 1) & (true_rec == 1)).sum())
    fp  = int(((pred_rec == 1) & (true_rec == 0)).sum())
    fn  = int(((pred_rec == 0) & (true_rec == 1)).sum())
    tn  = int(((pred_rec == 0) & (true_rec == 0)).sum())

    precision = tp / max(tp + fp, 1)
    recall    = tp / max(tp + fn, 1)
    f1        = 2 * precision * recall / max(precision + recall, 1e-8)
    accuracy  = (tp + tn) / n

    return {
        "Accuracy":  round(accuracy, 3),
        "Precision": round(precision, 3),
        "Recall":    round(recall, 3),
        "F1":        round(f1, 3),
        "N Recession Months": int(true_rec.sum()),
        "N Predicted Crisis": int(pred_rec.sum()),
    }
