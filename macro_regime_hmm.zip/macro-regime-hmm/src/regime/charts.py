"""
charts.py  ·  macro-regime-hmm
================================
Figures
1.  Regime overlay on macro features — the key diagnostic chart
2.  Regime transition matrix heatmap — stability of each regime
3.  Regime-conditional factor returns — the money table as a bar chart
4.  Feature distributions by regime — box plots for each macro feature
5.  Regime probability time series — P(s_t = k | X_{1:T}) stacked area
6.  Backtest equity curves — strategy vs equal-weight benchmark
7.  NBER recession vs HMM crisis regime — prediction accuracy
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd

from regime.features import REGIME_NAMES, REGIME_COLORS, FEATURE_COLS

logger = logging.getLogger(__name__)

FACTOR_COLORS = {
    "Mkt-RF": "#2166ac", "SMB": "#d6604d", "HML": "#4dac26",
    "RMW": "#762a83",    "CMA": "#a6761d", "MOM": "#c1121f",
}
FEATURE_LABELS = {
    "yield_curve":  "Yield Curve\n(10Y−2Y, %)",
    "hy_spread":    "HY Spread\n(OAS, %)",
    "vix":          "VIX",
    "unemp_change": "Unemployment\nChange (pp)",
    "equity_ret":   "Equity Return\n(monthly)",
    "equity_rvol":  "Equity Realized\nVol (ann.)",
}

plt.rcParams.update({
    "figure.facecolor": "white", "axes.facecolor": "white",
    "axes.spines.top": False,    "axes.spines.right": False,
    "font.size": 10,             "axes.titlesize": 12,
    "axes.titleweight": "bold",  "figure.dpi": 130,
})


def _save(fig, out: Path, name: str):
    p = out / name
    fig.savefig(p, bbox_inches="tight", dpi=150)
    plt.close(fig)
    logger.info("Saved %s", p)


def _shade_regimes(ax, regime_series: pd.Series, dates):
    """Shade background by regime state."""
    colors = {0: "#e8f5e9", 1: "#fff3e0", 2: "#ffebee"}
    prev_state, prev_date = None, None
    for date, state in zip(dates, regime_series.values):
        if np.isnan(state):
            continue
        state = int(state)
        if state != prev_state:
            if prev_state is not None and not np.isnan(prev_state):
                ax.axvspan(prev_date, date,
                           alpha=0.5, color=colors.get(prev_state, "#ffffff"),
                           linewidth=0)
            prev_state, prev_date = state, date
    if prev_state is not None and not np.isnan(prev_state):
        ax.axvspan(prev_date, dates[-1],
                   alpha=0.5, color=colors.get(prev_state, "#ffffff"), linewidth=0)


def fig1_regime_overlay(
    panel: pd.DataFrame,
    regime_series: pd.Series,
    out: Path,
) -> None:
    avail = [c for c in FEATURE_COLS if c in panel.columns][:6]
    ncols, nrows = 2, int(np.ceil(len(avail) / 2))
    fig, axes = plt.subplots(nrows, ncols, figsize=(16, 3.5 * nrows), sharex=True)
    axes_flat  = axes.flatten() if nrows > 1 else axes

    common  = panel.index.intersection(regime_series.dropna().index)
    reg_sub = regime_series.reindex(common)
    dates   = common.to_list()

    for ax, col in zip(axes_flat, avail):
        s = panel[col].reindex(common)
        _shade_regimes(ax, reg_sub, dates)
        ax.plot(common, s.values, color="#333333", lw=1.2)
        ax.axhline(s.mean(), color="#888888", lw=0.8, ls="--", alpha=0.6)
        ax.set_title(FEATURE_LABELS.get(col, col), fontweight="bold")
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
        ax.grid(axis="y", alpha=0.2)

    for ax in axes_flat[len(avail):]:
        ax.set_visible(False)

    # Legend
    patches = [mpatches.Patch(color=REGIME_COLORS[REGIME_NAMES[k]],
                               label=REGIME_NAMES[k]) for k in range(3)]
    fig.legend(handles=patches, loc="upper center", ncol=3,
               frameon=False, fontsize=10, bbox_to_anchor=(0.5, 1.01))
    fig.suptitle("Figure 1: Macro Features by Predicted Regime\n"
                 "Green = Expansion · Orange = Slowdown · Red = Crisis",
                 fontsize=12, fontweight="bold", y=1.03)
    plt.tight_layout()
    _save(fig, out, "fig1_regime_overlay.png")


def fig2_transition_matrix(hmm_result, out: Path) -> None:
    A      = hmm_result.params.A
    K      = len(A)
    labels = [REGIME_NAMES.get(k, f"S{k}") for k in range(K)]

    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(A, cmap="Blues", vmin=0, vmax=1)

    for i in range(K):
        for j in range(K):
            ax.text(j, i, f"{A[i,j]:.2f}", ha="center", va="center",
                    fontsize=13, fontweight="bold",
                    color="white" if A[i,j] > 0.6 else "black")

    ax.set_xticks(range(K)); ax.set_xticklabels(labels, fontsize=11)
    ax.set_yticks(range(K)); ax.set_yticklabels(labels, fontsize=11)
    ax.set_xlabel("To Regime");  ax.set_ylabel("From Regime")
    plt.colorbar(im, ax=ax, fraction=0.046, label="Transition Probability")
    ax.set_title("Figure 2: Regime Transition Matrix\n"
                 "Diagonal = persistence probability", pad=10)
    plt.tight_layout()
    _save(fig, out, "fig2_transition_matrix.png")


def fig3_factor_returns_by_regime(factor_table: pd.DataFrame, out: Path) -> None:
    """The money chart: momentum crushes in expansion, crashes in crisis."""
    factors  = factor_table.index.tolist()
    regimes  = [REGIME_NAMES[k] for k in range(3) if REGIME_NAMES[k] in factor_table.columns]
    if not regimes:
        regimes = [c for c in factor_table.columns if c != "All"]

    x  = np.arange(len(factors))
    bw = 0.25

    fig, ax = plt.subplots(figsize=(13, 6))
    regime_palette = {
        "Expansion": "#276749",
        "Slowdown":  "#a6761d",
        "Crisis":    "#c1121f",
    }

    for i, regime in enumerate(regimes):
        if regime not in factor_table.columns:
            continue
        vals = factor_table[regime].values * 100
        color = regime_palette.get(regime, "#888888")
        ax.bar(x + (i - 1) * bw, vals, bw * 0.9, color=color,
               alpha=0.85, label=regime, edgecolor="white")

    ax.axhline(0, color="black", lw=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(factors, fontsize=11)
    ax.set_ylabel("Annualised Factor Return (%)")
    ax.yaxis.set_major_formatter(mticker.PercentFormatter(decimals=1))
    ax.set_title("Figure 3: Regime-Conditional Factor Returns\n"
                 "Momentum strong in Expansion, crashes in Crisis — "
                 "Quality most stable across regimes",
                 pad=10)
    ax.legend(frameon=False, fontsize=10)
    ax.grid(axis="y", alpha=0.2)
    plt.tight_layout()
    _save(fig, out, "fig3_factor_returns_by_regime.png")


def fig4_feature_boxplots(panel: pd.DataFrame, regime_series: pd.Series, out: Path) -> None:
    avail = [c for c in FEATURE_COLS if c in panel.columns][:6]
    ncols, nrows = 3, 2
    fig, axes = plt.subplots(nrows, ncols, figsize=(16, 8))
    axes_flat = axes.flatten()

    common  = panel.index.intersection(regime_series.dropna().index)
    reg_sub = regime_series.reindex(common).astype(int)

    for ax, col in zip(axes_flat, avail):
        data_by_regime = [
            panel[col].reindex(common)[reg_sub == k].dropna().values
            for k in range(3)
        ]
        bplot = ax.boxplot(data_by_regime, labels=[REGIME_NAMES[k] for k in range(3)],
                           patch_artist=True, medianprops=dict(color="black", lw=2))
        colors_r = [REGIME_COLORS[REGIME_NAMES[k]] for k in range(3)]
        for patch, c in zip(bplot["boxes"], colors_r):
            patch.set_facecolor(c); patch.set_alpha(0.7)
        ax.set_title(FEATURE_LABELS.get(col, col), fontweight="bold")
        ax.grid(axis="y", alpha=0.2)

    for ax in axes_flat[len(avail):]:
        ax.set_visible(False)

    fig.suptitle("Figure 4: Macro Feature Distributions by Regime\n"
                 "Confirms regime labels align with economic intuition",
                 fontsize=12, fontweight="bold")
    plt.tight_layout()
    _save(fig, out, "fig4_feature_boxplots.png")


def fig5_regime_probs(hmm_result, panel: pd.DataFrame, out: Path) -> None:
    dates  = panel.index[:len(hmm_result.state_probs)]
    probs  = hmm_result.state_probs     # (T, K)

    fig, ax = plt.subplots(figsize=(14, 5))
    bottom  = np.zeros(len(dates))
    pal     = [REGIME_COLORS[REGIME_NAMES[k]] for k in range(probs.shape[1])]

    for k in range(probs.shape[1]):
        label = REGIME_NAMES.get(k, f"State {k}")
        ax.fill_between(dates, bottom, bottom + probs[:, k],
                        color=pal[k], alpha=0.85, label=label)
        bottom += probs[:, k]

    ax.set_ylim(0, 1)
    ax.set_ylabel("P(Regime | Data)")
    ax.yaxis.set_major_formatter(mticker.PercentFormatter(1.0))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    ax.set_title("Figure 5: Smoothed Regime Probabilities\n"
                 "P(s_t = k | x_{1:T}) from the Baum-Welch forward-backward algorithm",
                 pad=10)
    ax.legend(loc="upper left", frameon=False, fontsize=9)
    plt.tight_layout()
    _save(fig, out, "fig5_regime_probs.png")


def fig6_backtest(bt: Dict, out: Path) -> None:
    port_cum  = (1 + bt["returns"]).cumprod()
    bench_cum = (1 + bt["benchmark"]).cumprod()
    regimes   = bt["regime_series"]

    fig, axes = plt.subplots(2, 1, figsize=(14, 9), sharex=True)

    # NAV
    ax = axes[0]
    _shade_regimes(ax, regimes, regimes.index.tolist())
    ax.plot(port_cum.index,  port_cum.values,  color="#1a1a2e", lw=2.5,
            label="Regime-Conditional Strategy")
    ax.plot(bench_cum.index, bench_cum.values, color="#888888", lw=1.8,
            ls="--", label="Equal-Weight Factors")
    ax.axhline(1, color="black", lw=0.5)
    m = bt["metrics"]
    ax.set_title(
        f"Figure 6: Regime-Conditional Factor Strategy\n"
        f"Sharpe={m['Strategy']['Sharpe']:.2f} vs Benchmark={m['Benchmark']['Sharpe']:.2f}  "
        f"|  IR={m['Active'].get('Info Ratio','N/A')}",
        pad=10)
    ax.set_ylabel("Growth of $1")
    ax.legend(frameon=False, fontsize=9)
    ax.grid(axis="y", alpha=0.2)

    # Drawdown
    ax2 = axes[1]
    for s, color, label in [(port_cum, "#c1121f", "Strategy"), (bench_cum, "#888888", "Benchmark")]:
        peak = s.expanding().max()
        dd   = (s / peak - 1) * 100
        ax2.plot(s.index, dd.values, color=color, lw=1.5, alpha=0.8, label=label)
    ax2.fill_between(port_cum.index,
                     (port_cum / port_cum.expanding().max() - 1).values * 100,
                     0, alpha=0.2, color="#c1121f")
    ax2.axhline(0, color="black", lw=0.5)
    ax2.set_ylabel("Drawdown (%)")
    ax2.yaxis.set_major_formatter(mticker.PercentFormatter(decimals=1))
    ax2.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    ax2.legend(frameon=False, fontsize=9)
    ax2.grid(axis="y", alpha=0.2)

    plt.tight_layout()
    _save(fig, out, "fig6_backtest.png")


def fig7_nber_vs_hmm(
    regime_series: pd.Series,
    nber_rec:      pd.Series,
    out: Path,
) -> None:
    common  = regime_series.dropna().index.intersection(nber_rec.dropna().index)
    reg_sub = regime_series.reindex(common)
    nber    = nber_rec.reindex(common)

    fig, axes = plt.subplots(2, 1, figsize=(14, 7), sharex=True)

    ax = axes[0]
    crisis_binary = (reg_sub == 2).astype(int)
    ax.fill_between(common, 0, nber.values, color="#888888", alpha=0.5, label="NBER Recession")
    ax.fill_between(common, 0, crisis_binary.values * 0.8,
                    color="#c1121f", alpha=0.6, label="HMM Crisis Regime")
    ax.set_ylim(0, 1.2)
    ax.set_yticks([])
    ax.set_title("Figure 7: HMM Crisis Regime vs NBER Recessions\n"
                 "Quality of regime identification (no look-ahead)",
                 pad=10)
    ax.legend(frameon=False, fontsize=9)

    ax2 = axes[1]
    for k in range(3):
        prob = (reg_sub == k).astype(float).rolling(3).mean()
        color = REGIME_COLORS[REGIME_NAMES.get(k, f"State {k}")]
        ax2.plot(common, prob.values, color=color, lw=1.5,
                 label=REGIME_NAMES.get(k, f"State {k}"), alpha=0.85)
    ax2.fill_between(common, 0, nber.values * 0.3,
                     color="#888888", alpha=0.3, label="NBER Recession")
    ax2.set_ylabel("Regime Frequency (3M Roll)")
    ax2.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    ax2.legend(frameon=False, fontsize=9, ncol=4)
    ax2.grid(axis="y", alpha=0.2)

    plt.tight_layout()
    _save(fig, out, "fig7_nber_vs_hmm.png")


def save_all(panel, hmm_result, regime_series, factor_table, bt, out_dir):
    fig_dir = out_dir / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)

    fig1_regime_overlay(panel, regime_series, fig_dir)
    fig2_transition_matrix(hmm_result, fig_dir)
    fig3_factor_returns_by_regime(factor_table, fig_dir)
    fig4_feature_boxplots(panel, regime_series, fig_dir)
    fig5_regime_probs(hmm_result, panel, fig_dir)
    fig6_backtest(bt, fig_dir)

    nber = panel.get("nber_rec")
    if nber is not None:
        fig7_nber_vs_hmm(regime_series, nber, fig_dir)

    logger.info("All figures saved to %s", fig_dir)
