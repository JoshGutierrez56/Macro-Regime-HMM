"""
tests/test_hmm.py
==================
Unit tests for the Gaussian HMM — no internet, no API keys.
Synthetic data only.
"""
import sys
sys.path.insert(0, "src")

import numpy as np
import pandas as pd
from regime.hmm import GaussianHMM, HMMParams


def _make_3state_data(n=300, seed=42):
    """Synthetic 3-state data with well-separated Gaussians."""
    rng    = np.random.default_rng(seed)
    # True regime sequence with realistic persistence
    trans  = np.array([[0.90, 0.08, 0.02],
                       [0.10, 0.80, 0.10],
                       [0.20, 0.30, 0.50]])
    states = [0]
    for _ in range(n - 1):
        states.append(rng.choice(3, p=trans[states[-1]]))
    states = np.array(states)

    # Well-separated Gaussians in 2D
    means = np.array([[2.0, -1.0], [0.0, 0.0], [-2.0, 1.5]])
    X     = np.array([rng.multivariate_normal(means[s], np.eye(2) * 0.3)
                      for s in states])
    return X, states


def _make_2d_data(n=200, seed=1):
    rng = np.random.default_rng(seed)
    X0  = rng.multivariate_normal([1.0, 0.5], np.eye(2) * 0.5, n // 2)
    X1  = rng.multivariate_normal([-1.0, -0.5], np.eye(2) * 0.5, n // 2)
    return np.vstack([X0, X1])


# ── HMM initialisation ───────────────────────────────────────────────────────

def test_hmm_initialises():
    hmm = GaussianHMM(n_states=3)
    assert hmm.K == 3


def test_hmm_params_shapes():
    X, _ = _make_3state_data()
    hmm  = GaussianHMM(n_states=3)
    hmm.fit(X)
    p = hmm.result.params
    assert p.pi.shape    == (3,)
    assert p.A.shape     == (3, 3)
    assert p.mu.shape    == (3, 2)
    assert p.sigma.shape == (3, 2, 2)


# ── Parameter constraints ────────────────────────────────────────────────────

def test_initial_probs_sum_to_one():
    X, _ = _make_3state_data()
    hmm  = GaussianHMM(n_states=3)
    hmm.fit(X)
    np.testing.assert_allclose(hmm.result.params.pi.sum(), 1.0, atol=1e-6)


def test_transition_rows_sum_to_one():
    X, _ = _make_3state_data()
    hmm  = GaussianHMM(n_states=3)
    hmm.fit(X)
    row_sums = hmm.result.params.A.sum(axis=1)
    np.testing.assert_allclose(row_sums, np.ones(3), atol=1e-6)


def test_state_probs_sum_to_one():
    X, _ = _make_3state_data()
    hmm  = GaussianHMM(n_states=3)
    hmm.fit(X)
    row_sums = hmm.result.state_probs.sum(axis=1)
    np.testing.assert_allclose(row_sums, np.ones(len(X)), atol=1e-4)


def test_transition_probs_non_negative():
    X, _ = _make_3state_data()
    hmm  = GaussianHMM(n_states=3)
    hmm.fit(X)
    assert np.all(hmm.result.params.A >= 0)


# ── Fitting behaviour ────────────────────────────────────────────────────────

def test_log_likelihood_increases():
    """EM guarantee: log-likelihood is non-decreasing."""
    X, _ = _make_3state_data()
    hmm  = GaussianHMM(n_states=3, n_iter=50)
    hmm.fit(X)
    lls = hmm.result.log_likelihoods
    for i in range(1, len(lls)):
        assert lls[i] >= lls[i-1] - 0.01, \
            f"LL decreased at step {i}: {lls[i-1]:.2f} → {lls[i]:.2f}"


def test_fit_returns_result():
    X, _ = _make_3state_data()
    result = GaussianHMM(n_states=3).fit(X)
    assert result is not None
    assert result.n_obs == len(X)


def test_state_sequence_length():
    X, _ = _make_3state_data(n=200)
    hmm  = GaussianHMM(n_states=3)
    hmm.fit(X)
    assert len(hmm.result.state_sequence) == 200


def test_state_sequence_valid_values():
    X, _ = _make_3state_data()
    hmm  = GaussianHMM(n_states=3)
    hmm.fit(X)
    states = hmm.result.state_sequence
    assert set(states).issubset({0, 1, 2})


# ── Viterbi ──────────────────────────────────────────────────────────────────

def test_viterbi_length():
    X, _ = _make_3state_data(n=150)
    hmm  = GaussianHMM(n_states=3)
    hmm.fit(X)
    pred = hmm.predict(X[:50])
    assert len(pred) == 50


def test_viterbi_separated_clusters():
    """Well-separated clusters → Viterbi should assign them correctly."""
    X  = _make_2d_data(n=300, seed=10)
    hmm = GaussianHMM(n_states=2, n_iter=100, reg_covar=1e-3)
    hmm.fit(X)
    pred = hmm.predict(X)
    # First half should be mostly one state, second half mostly the other
    first_state  = int(np.median(pred[:100]))
    second_state = int(np.median(pred[150:]))
    assert first_state != second_state, "Should assign different states to separated clusters"


# ── 2-state model ────────────────────────────────────────────────────────────

def test_2state_model_fits():
    X, _ = _make_3state_data(n=200)
    hmm  = GaussianHMM(n_states=2)
    result = hmm.fit(X)
    assert result.n_states == 2
    assert result.params.A.shape == (2, 2)


# ── Regime alignment ─────────────────────────────────────────────────────────

def test_regime_labels_ordered_by_yield_curve():
    """After alignment, state 0 should have the highest yield_curve mean."""
    X, _ = _make_3state_data()
    hmm  = GaussianHMM(n_states=3)
    hmm.fit(X)
    # Feature 0 (first dimension = highest in state 0 after alignment)
    mu_f0 = hmm.result.params.mu[:, 0]
    assert mu_f0[0] >= mu_f0[1], "State 0 should have highest feature-0 mean (Expansion)"


if __name__ == "__main__":
    tests = [(k, v) for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = failed = 0
    for name, fn in tests:
        try:
            fn(); print(f"  ✅  {name}"); passed += 1
        except Exception as e:
            print(f"  ❌  {name}  →  {e}"); failed += 1
    print(f"\n  {passed} passed | {failed} failed")
