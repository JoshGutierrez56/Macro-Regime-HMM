"""
hmm.py  ·  macro-regime-hmm
=============================
Gaussian Hidden Markov Model — implemented from scratch.

No hmmlearn, no sklearn, no pomegranate. The algorithm is fully exposed
so every step is auditable and teachable.

Model
-----
K hidden states (regimes), D-dimensional Gaussian emissions.

Parameters θ = {π, A, μ, Σ}:
    π_k    : initial state probability
    A_kj   : transition probability P(s_t = j | s_{t-1} = k)
    μ_k    : emission mean for state k    (D-vector)
    Σ_k    : emission covariance for k    (D×D matrix)

Observation model:
    p(x_t | s_t = k) = N(x_t; μ_k, Σ_k)

Algorithm
---------
1. Baum-Welch EM (training)
   E-step: forward-backward algorithm → γ_t(k), ξ_t(k,j)
   M-step: update π, A, μ, Σ using γ and ξ
   Repeat until log-likelihood converges.

2. Viterbi decoding (inference)
   Dynamic programming to find most likely state sequence:
   δ_t(k) = max_{s_{1:t-1}} P(s_{1:t-1}, s_t=k, x_{1:t})

Forward-backward details
-------------------------
α_t(k) = P(x_{1:t}, s_t = k)     forward variable
β_t(k) = P(x_{t+1:T} | s_t = k)  backward variable

Computed in log space to prevent underflow on long sequences.

References
----------
Rabiner (1989) "A Tutorial on Hidden Markov Models and Selected
    Applications in Speech Recognition." Proc. IEEE.
Bishop (2006) "Pattern Recognition and Machine Learning." Ch. 13.
Hamilton (1989) "A New Approach to the Economic Analysis of Nonstationary
    Time Series." Econometrica — the finance application.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np
from scipy.stats import multivariate_normal

logger = logging.getLogger(__name__)

_LOG_EPS = -1e300   # floor for log(0)


@dataclass
class HMMParams:
    """Hidden Markov Model parameters."""
    pi:    np.ndarray   # (K,)    initial state distribution
    A:     np.ndarray   # (K, K)  transition matrix
    mu:    np.ndarray   # (K, D)  emission means
    sigma: np.ndarray   # (K, D, D) emission covariances
    K:     int = field(init=False)
    D:     int = field(init=False)

    def __post_init__(self):
        self.K = len(self.pi)
        self.D = self.mu.shape[1]


@dataclass
class HMMResult:
    """Fitted HMM output."""
    params:       HMMParams
    log_likelihoods: List[float]   # convergence trace
    converged:    bool
    n_obs:        int
    n_states:     int
    state_sequence: np.ndarray    # Viterbi-decoded states
    state_probs:    np.ndarray    # smoothed P(s_t = k | x_{1:T}), shape (T, K)


class GaussianHMM:
    """
    Gaussian-emission Hidden Markov Model trained by Baum-Welch EM.

    Parameters
    ----------
    n_states    : number of hidden states K
    n_iter      : maximum EM iterations
    tol         : convergence threshold on log-likelihood improvement
    reg_covar   : diagonal regularisation added to all covariance matrices
                  (prevents singularity when a state captures few observations)
    random_state: for reproducible initialisation
    """

    def __init__(
        self,
        n_states:     int   = 3,
        n_iter:       int   = 200,
        tol:          float = 1e-4,
        reg_covar:    float = 1e-4,
        random_state: int   = 42,
    ) -> None:
        self.K     = n_states
        self.n_iter = n_iter
        self.tol   = tol
        self.reg   = reg_covar
        self.rng   = np.random.default_rng(random_state)
        self.result: Optional[HMMResult] = None

    # ── Gaussian log-likelihood ───────────────────────────────────────────────

    def _log_emission(self, X: np.ndarray, params: HMMParams) -> np.ndarray:
        """
        log p(x_t | s_t = k) for all t, k.
        Returns shape (T, K).
        """
        T = X.shape[0]
        log_b = np.zeros((T, self.K))
        for k in range(self.K):
            try:
                rv = multivariate_normal(
                    mean=params.mu[k],
                    cov=params.sigma[k] + self.reg * np.eye(params.D),
                    allow_singular=True,
                )
                log_b[:, k] = rv.logpdf(X)
            except Exception:
                log_b[:, k] = _LOG_EPS
        return log_b

    # ── Forward algorithm (log-space) ──────────────────────────────────────────

    def _forward(
        self, log_b: np.ndarray, params: HMMParams
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Scaled forward algorithm in log space.

        Returns
        -------
        log_alpha : (T, K) log forward variables
        log_scale : (T,)   per-step normalisation constants (for log-likelihood)
        """
        T, K   = log_b.shape
        log_alpha = np.full((T, K), _LOG_EPS)
        log_scale = np.zeros(T)

        # t = 0: α_0(k) = π_k · b_k(x_0)
        log_alpha[0] = np.log(params.pi + 1e-300) + log_b[0]
        log_scale[0] = np.logaddexp.reduce(log_alpha[0])
        log_alpha[0] -= log_scale[0]

        # t > 0: α_t(j) = b_j(x_t) · Σ_k α_{t-1}(k) · A_kj
        log_A = np.log(params.A + 1e-300)
        for t in range(1, T):
            for j in range(K):
                log_alpha[t, j] = (log_b[t, j]
                    + np.logaddexp.reduce(log_alpha[t-1] + log_A[:, j]))
            log_scale[t] = np.logaddexp.reduce(log_alpha[t])
            log_alpha[t] -= log_scale[t]

        return log_alpha, log_scale

    # ── Backward algorithm (log-space) ─────────────────────────────────────────

    def _backward(
        self, log_b: np.ndarray, log_scale: np.ndarray, params: HMMParams
    ) -> np.ndarray:
        """
        Scaled backward algorithm in log space.

        Returns
        -------
        log_beta : (T, K) log backward variables
        """
        T, K   = log_b.shape
        log_beta = np.zeros((T, K))
        log_A    = np.log(params.A + 1e-300)

        for t in range(T - 2, -1, -1):
            for k in range(K):
                log_beta[t, k] = (
                    np.logaddexp.reduce(
                        log_A[k] + log_b[t+1] + log_beta[t+1]
                    ) - log_scale[t+1]
                )
        return log_beta

    # ── E-step: compute γ and ξ ────────────────────────────────────────────────

    def _e_step(
        self, X: np.ndarray, params: HMMParams
    ) -> Tuple[np.ndarray, np.ndarray, float]:
        """
        E-step: compute state occupancy γ and transition ξ.

        γ_t(k)  = P(s_t = k | X, θ)          shape (T, K)
        ξ_t(k,j)= P(s_t=k, s_{t+1}=j | X, θ) shape (T-1, K, K)
        """
        T, K   = X.shape[0], self.K
        log_b  = self._log_emission(X, params)
        log_alpha, log_scale = self._forward(log_b, params)
        log_beta = self._backward(log_b, log_scale, params)
        log_gamma = log_alpha + log_beta

        # Normalise γ at each t
        log_gamma_norm = log_gamma - np.logaddexp.reduce(log_gamma, axis=1, keepdims=True)
        gamma = np.exp(log_gamma_norm)

        # ξ_t(k,j) = α_t(k) · A_kj · b_j(x_{t+1}) · β_{t+1}(j)  / Z
        log_A = np.log(params.A + 1e-300)
        xi    = np.zeros((T - 1, K, K))
        for t in range(T - 1):
            for k in range(K):
                for j in range(K):
                    xi[t, k, j] = (log_alpha[t, k]
                                   + log_A[k, j]
                                   + log_b[t+1, j]
                                   + log_beta[t+1, j])
            # Normalise
            xi_max = xi[t].max()
            xi[t]  = np.exp(xi[t] - xi_max)
            xi[t] /= xi[t].sum() + 1e-300

        log_likelihood = float(log_scale.sum())
        return gamma, xi, log_likelihood

    # ── M-step: update parameters ──────────────────────────────────────────────

    def _m_step(
        self, X: np.ndarray, gamma: np.ndarray, xi: np.ndarray
    ) -> HMMParams:
        """
        M-step: maximise expected log-likelihood by updating θ.
        """
        T, K = gamma.shape
        D    = X.shape[1]

        # Initial state
        pi = gamma[0] / (gamma[0].sum() + 1e-300)
        pi = np.maximum(pi, 1e-6); pi /= pi.sum()

        # Transition matrix
        A = xi.sum(axis=0)
        A /= (A.sum(axis=1, keepdims=True) + 1e-300)
        A = np.maximum(A, 1e-6)
        A /= A.sum(axis=1, keepdims=True)

        # Emission means
        gamma_sum = gamma.sum(axis=0) + 1e-300   # (K,)
        mu    = (gamma[:, :, None] * X[:, None, :]).sum(axis=0) / gamma_sum[:, None]

        # Emission covariances
        sigma = np.zeros((K, D, D))
        for k in range(K):
            diff = X - mu[k]                              # (T, D)
            weighted = gamma[:, k:k+1] * diff             # (T, D)
            sigma[k] = (weighted.T @ diff) / gamma_sum[k]
            sigma[k] += self.reg * np.eye(D)              # regularise

        return HMMParams(pi=pi, A=A, mu=mu, sigma=sigma)

    # ── Viterbi decoding ───────────────────────────────────────────────────────

    def viterbi(self, X: np.ndarray, params: HMMParams) -> np.ndarray:
        """
        Find the most likely state sequence via Viterbi dynamic programming.

        Returns
        -------
        np.ndarray  — state sequence (T,), values in 0..K-1
        """
        T     = X.shape[0]
        log_b = self._log_emission(X, params)
        log_A = np.log(params.A + 1e-300)

        delta = np.full((T, self.K), _LOG_EPS)
        psi   = np.zeros((T, self.K), dtype=int)

        delta[0] = np.log(params.pi + 1e-300) + log_b[0]

        for t in range(1, T):
            for j in range(self.K):
                scores     = delta[t-1] + log_A[:, j]
                psi[t, j]  = np.argmax(scores)
                delta[t, j] = scores[psi[t, j]] + log_b[t, j]

        # Backtrack
        states    = np.zeros(T, dtype=int)
        states[T-1] = np.argmax(delta[T-1])
        for t in range(T - 2, -1, -1):
            states[t] = psi[t + 1, states[t + 1]]

        return states

    # ── Initialisation ─────────────────────────────────────────────────────────

    def _initialise(self, X: np.ndarray) -> HMMParams:
        """
        K-means++ initialisation for emission means.
        Uniform initial transition matrix. Uniform initial state.
        """
        T, D = X.shape
        K    = self.K

        # K-means++ seed selection for emission means
        mu = np.zeros((K, D))
        mu[0] = X[self.rng.integers(T)]
        for k in range(1, K):
            dists = np.array([min(np.sum((X[t] - mu[j]) ** 2) for j in range(k))
                              for t in range(T)])
            probs = dists / dists.sum()
            mu[k] = X[self.rng.choice(T, p=probs)]

        pi    = np.ones(K) / K
        A     = np.ones((K, K)) / K
        sigma = np.array([np.eye(D) * X.var(axis=0).mean() for _ in range(K)])

        return HMMParams(pi=pi, A=A, mu=mu, sigma=sigma)

    # ── Main fit ───────────────────────────────────────────────────────────────

    def fit(self, X: np.ndarray) -> HMMResult:
        """
        Fit the HMM to observation sequence X via Baum-Welch EM.

        Parameters
        ----------
        X : np.ndarray  — shape (T, D), T observations of D features

        Returns
        -------
        HMMResult
        """
        T, D    = X.shape
        params  = self._initialise(X)
        log_lls = []
        prev_ll = -np.inf

        for i in range(self.n_iter):
            gamma, xi, ll = self._e_step(X, params)
            params         = self._m_step(X, gamma, xi)
            log_lls.append(ll)

            improvement = ll - prev_ll
            if i > 5 and improvement < self.tol:
                logger.info("EM converged at iteration %d (ΔLL=%.6f)", i, improvement)
                break
            prev_ll = ll

        converged = len(log_lls) < self.n_iter
        states    = self.viterbi(X, params)
        gamma, _, _ = self._e_step(X, params)

        self.result = HMMResult(
            params=params,
            log_likelihoods=log_lls,
            converged=converged,
            n_obs=T,
            n_states=self.K,
            state_sequence=states,
            state_probs=gamma,
        )
        self._fitted_params = params

        # Align regimes by mean yield curve (ascending → [crisis, slowdown, expansion])
        self._align_regime_labels(X)

        logger.info(
            "HMM fitted: K=%d  T=%d  LL=%.2f  converged=%s",
            self.K, T, log_lls[-1], converged,
        )
        return self.result

    def _align_regime_labels(self, X: np.ndarray) -> None:
        """
        Permute state labels so:
            state 0 = Expansion  (highest yield curve / equity return)
            state 1 = Slowdown
            state 2 = Crisis     (lowest / most stress)
        Uses mean yield curve (feature 0) to define ordering.
        """
        if X.shape[1] < 1:
            return
        means_yc = self._fitted_params.mu[:, 0]   # yield curve mean per state
        order    = np.argsort(means_yc)[::-1]      # descending: expansion first

        old_states = self.result.state_sequence.copy()
        old_probs  = self.result.state_probs.copy()
        old_mu     = self._fitted_params.mu.copy()
        old_sigma  = self._fitted_params.sigma.copy()
        old_pi     = self._fitted_params.pi.copy()
        old_A      = self._fitted_params.A.copy()

        mapping = {old: new for new, old in enumerate(order)}

        self.result.state_sequence = np.array([mapping[s] for s in old_states])
        self.result.state_probs    = old_probs[:, order]
        self._fitted_params.mu     = old_mu[order]
        self._fitted_params.sigma  = old_sigma[order]
        self._fitted_params.pi     = old_pi[order]
        self._fitted_params.A      = old_A[np.ix_(order, order)]

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict regime sequence for new observations (uses fitted params)."""
        if self.result is None:
            raise RuntimeError("Model not fitted")
        return self.viterbi(X, self._fitted_params)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Smoothed state probabilities for new observations."""
        if self.result is None:
            raise RuntimeError("Model not fitted")
        gamma, _, _ = self._e_step(X, self._fitted_params)
        return gamma
