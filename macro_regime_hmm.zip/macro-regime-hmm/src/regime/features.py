"""
features.py  ·  macro-regime-hmm
==================================
Feature engineering for the macro regime HMM.

Pre-processing pipeline
-----------------------
1. Standardise each feature to mean=0, std=1 (expanding window for walk-forward)
2. Optionally apply PCA for dimensionality reduction (not default)
3. Compute regime-conditional statistics for each factor

Walk-forward design
-------------------
For a T-month panel with train_size initial periods:
  - Fit HMM on months 1..train_size
  - Predict regime for month train_size+1
  - Expand window by 1, refit, predict next
  - Repeat to end of sample

This avoids look-ahead bias: the regime label at time t is always
predicted using only data available at t.

Regime-conditional factor returns
-----------------------------------
For each regime k and each factor f:
    μ_k(f)  = E[r_f | s_t = k]   (mean factor return in regime k)
    σ_k(f)  = std[r_f | s_t = k]
    SR_k(f) = μ_k(f) / σ_k(f)   (regime-conditional Sharpe)

This is the money table. Momentum crushes in crisis regimes.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from regime.hmm import GaussianHMM

logger = logging.getLogger(__name__)

FEATURE_COLS = ["yield_curve", "hy_spread", "vix",
                "unemp_change", "equity_ret", "equity_rvol"]
REGIME_NAMES = {0: "Expansion", 1: "Slowdown", 2: "Crisis"}
REGIME_COLORS = {"Expansion": "#276749", "Slowdown": "#a6761d", "Crisis": "#c1121f"}


def standardise(
    panel:       pd.DataFrame,
    feature_cols: List[str] = FEATURE_COLS,
    expanding:   bool = False,
) -> pd.DataFrame:
    """
    Z-score each feature. If expanding=True, use expanding window statistics
    (appropriate for walk-forward to avoid look-ahead bias).
    """
    result = panel.copy()
    for col in feature_cols:
        if col not in panel.columns:
            continue
        s = panel[col]
        if expanding:
            mu   = s.expanding(min_periods=12).mean()
            std  = s.expanding(min_periods=12).std(ddof=1).replace(0, 1).fillna(1)
            result[col] = (s - mu) / std
        else:
            mu, std = s.mean(), s.std(ddof=1)
            result[col] = (s - mu) / (std if std > 1e-10 else 1.0)
    return result


def fit_hmm_on_panel(
    panel:         pd.DataFrame,
    n_states:      int = 3,
    feature_cols:  List[str] = FEATURE_COLS,
    reg_covar:     float = 1e-3,
) -> Tuple[GaussianHMM, np.ndarray]:
    """
    Fit HMM on the full panel. Returns fitted model and state sequence.
    """
    feat_panel = standardise(panel, feature_cols, expanding=False)
    X = feat_panel[feature_cols].dropna().values

    hmm = GaussianHMM(n_states=n_states, reg_covar=reg_covar, random_state=42)
    result = hmm.fit(X)
    return hmm, result.state_sequence


def walk_forward_regimes(
    panel:        pd.DataFrame,
    n_states:     int   = 3,
    train_size:   int   = 60,   # months of initial training window
    feature_cols: List[str] = FEATURE_COLS,
    reg_covar:    float = 1e-3,
) -> pd.Series:
    """
    Walk-forward HMM: predict one month ahead using expanding window.

    Returns
    -------
    pd.Series  — predicted regime label per month (index = panel.index)
    """
    feat_panel = standardise(panel, feature_cols, expanding=True)
    X_all = feat_panel[feature_cols].dropna().values
    dates = feat_panel[feature_cols].dropna().index
    T     = len(X_all)

    if T < train_size + 6:
        logger.warning("Insufficient data for walk-forward (T=%d, train=%d)", T, train_size)
        # Fall back to full-sample fit
        hmm, states = fit_hmm_on_panel(panel, n_states, feature_cols, reg_covar)
        return pd.Series(states, index=dates, name="regime")

    predicted = np.full(T, np.nan)
    hmm = None

    for t in range(train_size, T):
        X_train = X_all[:t]

        # Refit every 12 months or on first iteration
        if hmm is None or (t - train_size) % 12 == 0:
            try:
                hmm = GaussianHMM(n_states=n_states, reg_covar=reg_covar,
                                  random_state=42)
                hmm.fit(X_train)
            except Exception as exc:
                logger.warning("HMM fit failed at t=%d: %s", t, exc)
                continue

        # Predict current month using fitted model
        try:
            state = hmm.predict(X_all[t:t+1])[0]
            predicted[t] = int(state)
        except Exception:
            predicted[t] = 0   # fallback to expansion

    series = pd.Series(predicted, index=dates, name="regime")
    logger.info("Walk-forward regimes: %d months predicted | coverage: %.1f%%",
                T - train_size,
                100 * (series >= 0).sum() / T)
    return series


def regime_statistics(
    regime_series:  pd.Series,
    panel:          pd.DataFrame,
    factor_returns: pd.DataFrame,
    n_states:       int = 3,
) -> pd.DataFrame:
    """
    Compute regime-conditional summary statistics.

    Returns
    -------
    pd.DataFrame  — rows = (regime, metric), cols = features + factors
    """
    macro_cols  = [c for c in FEATURE_COLS if c in panel.columns]
    factor_cols = [c for c in ["Mkt-RF", "SMB", "HML", "RMW", "CMA", "MOM"]
                   if c in factor_returns.columns]

    rows = []
    common_idx = regime_series.dropna().index

    for k in range(n_states):
        name = REGIME_NAMES.get(k, f"State {k}")
        mask = (regime_series.reindex(common_idx) == k)
        n_months = int(mask.sum())

        for col in macro_cols:
            if col not in panel.columns:
                continue
            s = panel[col].reindex(common_idx)[mask]
            rows.append({"regime": name, "variable": col, "type": "macro",
                         "mean": s.mean(), "std": s.std(), "n_months": n_months})

        for col in factor_cols:
            if col not in factor_returns.columns:
                continue
            s = factor_returns[col].reindex(common_idx)[mask].dropna()
            if len(s) < 3:
                continue
            ann = 12
            mu  = s.mean() * ann
            sig = s.std(ddof=1) * np.sqrt(ann)
            rows.append({"regime": name, "variable": col, "type": "factor",
                         "mean": mu, "std": sig,
                         "sharpe": mu / sig if sig > 0 else np.nan,
                         "n_months": n_months})

    return pd.DataFrame(rows)


def regime_factor_table(
    regime_series:  pd.Series,
    factor_returns: pd.DataFrame,
    n_states:       int = 3,
    annualise:      bool = True,
) -> pd.DataFrame:
    """
    Compact pivot table: factor × regime → annualised mean return.
    This is the primary output recruiters care about.
    """
    factor_cols = [c for c in ["Mkt-RF", "SMB", "HML", "RMW", "CMA", "MOM"]
                   if c in factor_returns.columns]
    scale = 12 if annualise else 1
    common = regime_series.dropna().index.intersection(factor_returns.index)
    regimes = regime_series.reindex(common)
    factors = factor_returns.reindex(common)

    rows = {}
    for col in factor_cols:
        row = {}
        for k in range(n_states):
            name = REGIME_NAMES.get(k, f"State {k}")
            mask = regimes == k
            s    = factors[col][mask].dropna()
            row[name] = s.mean() * scale if len(s) > 3 else np.nan
        row["All"] = factors[col].dropna().mean() * scale
        rows[col]  = row

    return pd.DataFrame(rows).T
