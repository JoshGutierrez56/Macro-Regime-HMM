"""
data.py  ·  macro-regime-hmm
==============================
Macro feature download — zero API keys required.

FRED data via direct CSV URL
-----------------------------
The St. Louis Fed publishes every series as a downloadable CSV at:
    https://fred.stlouisfed.org/graph/fredgraph.csv?id={SERIES_ID}

No registration, no API key, no rate limits (within reason).
We cache each series locally so reruns don't re-download.

Six macro features
------------------
1. yield_curve   : T10Y2Y — 10-year minus 2-year Treasury spread (%)
                   The most widely studied recession predictor.
                   Inverted (< 0) has preceded every US recession since 1955.

2. hy_spread     : BAMLH0A0HYM2 — ICE BofA US HY Option-Adjusted Spread (%)
                   Credit stress indicator. Widening precedes growth slowdowns.
                   Data from Federal Reserve H.15 via FRED.

3. vix           : VIXCLS — CBOE VIX daily close, monthly average
                   Market's implied 30-day vol expectation. > 30 = stress.

4. unemp_change  : UNRATE month-over-month change
                   Rising unemployment = expansion ending.

5. equity_ret    : SPY monthly total return (yfinance)
                   Growth proxy at market frequency.

6. equity_rvol   : 21-day rolling realized vol of SPY returns (annualised)
                   Forward-looking regime signal: spikes before recessions.

NBER recession indicator (for evaluation, not features)
--------------------------------------------------------
USREC — 1 = recession month (NBER dating), 0 = expansion.
Used only to label regimes ex-post and evaluate HMM accuracy.
NOT fed into the HMM during training (that would be cheating).
"""
from __future__ import annotations

import io
import logging
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import requests

logger = logging.getLogger(__name__)

FRED_URL  = "https://fred.stlouisfed.org/graph/fredgraph.csv?id={}"
CACHE_DIR = Path("data/cache")
HEADERS   = {"User-Agent": "macro-regime-hmm academic research"}

FRED_SERIES = {
    "yield_curve": "T10Y2Y",
    "hy_spread":   "BAMLH0A0HYM2",
    "vix":         "VIXCLS",
    "unemp":       "UNRATE",
    "nber_rec":    "USREC",
}


def _fetch_fred(series_id: str, cache_dir: Path = CACHE_DIR) -> pd.Series:
    """Download a FRED series as a monthly pd.Series (no API key)."""
    cache_path = cache_dir / f"{series_id}.parquet"
    if cache_path.exists():
        return pd.read_parquet(cache_path).squeeze()

    url = FRED_URL.format(series_id)
    try:
        time.sleep(0.3)
        resp = requests.get(url, headers=HEADERS, timeout=30)
        resp.raise_for_status()
        df = pd.read_csv(io.StringIO(resp.text), index_col=0, parse_dates=True)
        df.columns = [series_id]
        df = df.replace(".", np.nan).astype(float)
        s  = df[series_id].dropna()
        cache_dir.mkdir(parents=True, exist_ok=True)
        s.to_frame().to_parquet(cache_path)
        logger.info("Downloaded FRED %s: %d obs (%s → %s)",
                    series_id, len(s), s.index[0].date(), s.index[-1].date())
        return s
    except Exception as exc:
        logger.warning("FRED download failed for %s: %s", series_id, exc)
        return pd.Series(dtype=float, name=series_id)


def _fetch_spy(start: str = "2000-01-01", cache_dir: Path = CACHE_DIR) -> pd.DataFrame:
    """Download SPY daily prices via yfinance."""
    cache_path = cache_dir / "spy_prices.parquet"
    if cache_path.exists():
        return pd.read_parquet(cache_path)

    try:
        import yfinance as yf
        raw = yf.download("SPY", start=start, auto_adjust=True, progress=False)
        prices = raw[["Close"]].copy()
        prices.index = pd.DatetimeIndex(prices.index)
        if hasattr(prices.index, "tz") and prices.index.tz:
            prices.index = prices.index.tz_localize(None)
        cache_dir.mkdir(parents=True, exist_ok=True)
        prices.to_parquet(cache_path)
        logger.info("Downloaded SPY: %d days", len(prices))
        return prices
    except Exception as exc:
        logger.warning("yfinance failed: %s — using synthetic SPY", exc)
        return pd.DataFrame()


def build_feature_panel(
    start:     str = "2000-01-01",
    end:       Optional[str] = None,
    cache_dir: str = "data/cache",
    offline:   bool = False,
) -> pd.DataFrame:
    """
    Build the monthly macro feature panel for the HMM.

    Returns
    -------
    pd.DataFrame  — monthly index, columns: yield_curve, hy_spread, vix,
                    unemp_change, equity_ret, equity_rvol
    Plus a 'nber_rec' column (not a feature — evaluation label only).
    """
    cache = Path(cache_dir)

    if offline:
        logger.warning("OFFLINE mode — generating synthetic macro features")
        return _synthetic_features(start, end)

    # ── FRED series (monthly) ─────────────────────────────────────────
    raw = {}
    for name, sid in FRED_SERIES.items():
        raw[name] = _fetch_fred(sid, cache)

    # ── SPY (daily → monthly) ──────────────────────────────────────────
    spy_daily = _fetch_spy(start=start, cache_dir=cache)
    if spy_daily.empty:
        spy_daily = _synthetic_spy(start, end)

    spy_ret  = spy_daily["Close"].pct_change()
    spy_rvol = spy_ret.rolling(21).std() * np.sqrt(252)

    # Monthly resample
    spy_mret  = (1 + spy_ret).resample("MS").prod() - 1
    spy_mrvol = spy_rvol.resample("MS").mean()

    # ── Assemble panel ─────────────────────────────────────────────────
    df = pd.DataFrame({
        "yield_curve":  raw["yield_curve"].resample("MS").last(),
        "hy_spread":    raw["hy_spread"].resample("MS").last(),
        "vix":          raw["vix"].resample("MS").mean(),
        "unemp_change": raw["unemp"].resample("MS").last().diff(),
        "equity_ret":   spy_mret,
        "equity_rvol":  spy_mrvol,
        "nber_rec":     raw["nber_rec"].resample("MS").max(),
    })

    # Filter date range
    df.index = pd.DatetimeIndex(df.index).tz_localize(None)
    if end:
        df = df.loc[start:end]
    else:
        df = df.loc[start:]

    df = df.dropna(subset=["yield_curve", "hy_spread", "vix",
                            "unemp_change", "equity_ret"])

    logger.info("Feature panel: %d months (%s → %s)",
                len(df), df.index[0].date(), df.index[-1].date())
    return df


def get_ff_factor_returns(
    start:     str = "2000-01-01",
    cache_dir: str = "data/cache",
    offline:   bool = False,
) -> pd.DataFrame:
    """
    Monthly Fama-French 6 factor returns from Kenneth French's data library.
    Used for regime-conditional factor analysis (not HMM features).

    We download via yfinance as factor-mimicking ETFs when offline,
    or as direct CSV from French's library when online.
    """
    cache = Path(cache_dir) / "ff_factors.parquet"
    if cache.exists():
        return pd.read_parquet(cache)

    if offline:
        return _synthetic_factor_returns(start)

    try:
        # French's monthly 5-factor CSV
        url = ("https://mba.tuck.dartmouth.edu/pages/faculty/ken.french/"
               "ftp/F-F_Research_Data_5_Factors_2x3_CSV.zip")
        df  = pd.read_csv(url, skiprows=3)
        df.columns = df.columns.str.strip()
        # Find end of monthly data (blank row before annual)
        end_idx = df[df.iloc[:, 0].astype(str).str.match(r"^\s*$")].index
        if len(end_idx):
            df = df.iloc[:len(end_idx[0])]
        df = df.rename(columns={df.columns[0]: "Date"})
        df["Date"] = pd.to_datetime(df["Date"].astype(str).str.strip(), format="%Y%m")
        df = df.set_index("Date")
        df = df.apply(pd.to_numeric, errors="coerce") / 100
        df.to_parquet(cache)
        return df
    except Exception as exc:
        logger.warning("French data download failed: %s — using ETF proxies", exc)
        return _synthetic_factor_returns(start)


# ── Synthetic fallbacks ──────────────────────────────────────────────────────

def _synthetic_features(start: str, end: Optional[str]) -> pd.DataFrame:
    """Generate synthetic macro panel with realistic regime structure."""
    rng   = np.random.default_rng(42)
    dates = pd.date_range(start=start, end=end or "2024-12-01", freq="MS")
    n     = len(dates)

    # Three-state Markov regime process
    # State 0 = Expansion, 1 = Slowdown, 2 = Crisis
    trans = np.array([
        [0.92, 0.07, 0.01],   # Expansion → stay 92%, slow 7%, crisis 1%
        [0.15, 0.75, 0.10],   # Slowdown  → expand 15%, stay 75%, crisis 10%
        [0.30, 0.40, 0.30],   # Crisis    → expand 30%, slow 40%, stay 30%
    ])
    state = 0
    states = []
    for _ in range(n):
        states.append(state)
        state = rng.choice(3, p=trans[state])
    states = np.array(states)

    # Feature means and stds by regime
    means = {
        "yield_curve":  [1.5,  0.1,  -0.5],   # expansion/slow/crisis
        "hy_spread":    [3.5,  5.5,  10.0],
        "vix":          [14.0, 22.0,  35.0],
        "unemp_change": [-0.02, 0.05, 0.25],
        "equity_ret":   [0.012, -0.003, -0.04],
        "equity_rvol":  [0.12,  0.20,   0.40],
    }
    stds = {
        "yield_curve":  [0.5,  0.4, 0.5],
        "hy_spread":    [0.8,  1.5, 2.5],
        "vix":          [3.0,  5.0, 8.0],
        "unemp_change": [0.05, 0.08, 0.15],
        "equity_ret":   [0.04,  0.05, 0.07],
        "equity_rvol":  [0.03,  0.05, 0.10],
    }

    data = {}
    for feat in means:
        vals = np.array([
            rng.normal(means[feat][s], stds[feat][s])
            for s in states
        ])
        data[feat] = vals

    df = pd.DataFrame(data, index=dates)
    df["nber_rec"] = (states >= 2).astype(int)   # crisis = recession
    df["true_regime"] = states                    # ground truth for evaluation
    return df


def _synthetic_spy(start: str, end: Optional[str]) -> pd.DataFrame:
    rng   = np.random.default_rng(99)
    dates = pd.bdate_range(start=start, end=end or "2024-12-31")
    ret   = rng.normal(0.0003, 0.012, len(dates))
    close = pd.Series(100.0 * np.cumprod(1 + ret), index=dates, name="Close")
    return close.to_frame()


def _synthetic_factor_returns(start: str) -> pd.DataFrame:
    rng   = np.random.default_rng(7)
    dates = pd.date_range(start=start, end="2024-12-01", freq="MS")
    n     = len(dates)
    df    = pd.DataFrame({
        "Mkt-RF": rng.normal(0.008, 0.045, n),
        "SMB":    rng.normal(0.001, 0.030, n),
        "HML":    rng.normal(0.002, 0.030, n),
        "RMW":    rng.normal(0.003, 0.022, n),
        "CMA":    rng.normal(0.001, 0.020, n),
        "MOM":    rng.normal(0.006, 0.040, n),
        "RF":     np.full(n, 0.0035),
    }, index=dates)
    return df
